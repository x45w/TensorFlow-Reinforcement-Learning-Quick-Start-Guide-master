# DDPG_TORCS2
DDPG with Gaussian noise for autonomous driving in TORCS


Driving a Car in TORCS using Deep Reinforcement Learning


In the training phase, set irestart = 0 for restart from scratch;
If restarting from a ckpt file, then set irestart = 1 and restart_step = ckpt iteration number (e.g., 1300)


Youtube link:
https://www.youtube.com/watch?v=ajomz08hSIE

